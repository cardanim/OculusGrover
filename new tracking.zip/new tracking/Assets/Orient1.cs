﻿
using UnityEngine;

using System.IO.Ports;

using System.Threading;


public class Orient1 : MonoBehaviour
{
    private SerialPort port = new SerialPort("COM3",9600, Parity.None, 8, StopBits.One);
    // Use this for initialization
    void Start()
    {
        port.Open();
    }

    void Update()
    {
        Vector3 vector = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z);
        if (vector[0] < 90) {
            vector[0] = 90 - vector[0];
            vector[0] = 180 - vector[0]; }
        else if (vector[0] > 270) {
            vector[0] = 90 + (360 - vector[0]);
            vector[0] = 180 - vector[0]; }
        else if (vector[0] < 180)
            vector[0] = 180;
        else if (vector[0] > 180)
            vector[0] = 0;
        //else
        //    vector[0] = 90;
        if (vector[1] < 90)
            vector[1] = 90 - vector[1];
        else if (vector[1] > 270)
            vector[1] = 90 + (360 - vector[1]);
        else if (vector[1] < 180)
            vector[1] = 0;
        else if (vector[1] > 180)
            vector[1] = 180;

        //else
        //    vector[1] = 90;
        string s = vector.ToString();
        int start = s.LastIndexOf("(");
        int end = s.LastIndexOf(")");
        string result = s.Substring(start + 1, end - start - 1);
        port.WriteLine(result);
        Thread.Sleep(10);


        //    string path = @"C:\temp\Servocom.txt";
        //    if (File.Exists(path))
        //    {
        //        File.Delete(path);
        //    }
        //    //using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None)
        //    using (FileStream fs = File.Create(path))
        //    {
        //        AddText(fs, result);
        //    }

        //    using (FileStream fs = File.OpenRead(path))
        //    {
        //        byte[] b = new byte[1024];
        //        UTF8Encoding temp = new UTF8Encoding(true);
        //        while (fs.Read(b,0,b.Length)>0)
        //        {
        //            Console.WriteLine(temp.GetString(b));
        //        }
        //    }
        //}
        //private static void AddText(FileStream fs, string value)
        //{
        //    byte[] info = new UTF8Encoding(true).GetBytes(value);
        //    fs.Write(info, 0, info.Length);
        //}

    }
}