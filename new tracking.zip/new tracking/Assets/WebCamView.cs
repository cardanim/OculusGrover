﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WebCamView : MonoBehaviour {
	// Use this for initialization
	void Start () {
	    WebCamDevice[] devices = WebCamTexture.devices;
        for (var i = 0; i < devices.Length; i++)
            Debug.Log(devices[i].name);
        Renderer rend = this.GetComponentInChildren<Renderer>();
        WebCamTexture tex = new WebCamTexture(devices[0].name);
        rend.material.mainTexture = tex;
        tex.Play();
	}
	
}
